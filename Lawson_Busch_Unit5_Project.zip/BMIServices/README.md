# BMI-services
Project for SOAP and REST webservices utilizing C# and .NET. Contains two directories - SoapService for the SOAP implementation and RestService for the REST implementation.

Develop using Visual Studio 2022 and WCF Services. Run by opening the BMIServices.sln in visual studio and running with the IIS server.
